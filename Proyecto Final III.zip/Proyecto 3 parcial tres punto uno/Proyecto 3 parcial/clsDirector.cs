﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_3_parcial
{
    // Homonimia: clsDirector representa un director nominado al Oscar
    class clsDirector : clsNominaciones
    {
        // Constructor por defecto
        public clsDirector() { }

        // Constructor con parámetros, llamando al constructor de la superclase
        public clsDirector(int id, string nombre, string descripcion, string foto, string nombreFoto, int idCategoria)
            : base(id, nombre, descripcion, foto, nombreFoto, idCategoria)
        {
        }

        // Función virtual sobrescrita para mostrar un mensaje específico de Director
        public override void mensaje()
        {
            MessageBox.Show($"Director: {Nombre}\n" +
                            $"Descripción: {Descripcion}\n" +
                            $"Foto: {Foto}");
        }
    }
}
