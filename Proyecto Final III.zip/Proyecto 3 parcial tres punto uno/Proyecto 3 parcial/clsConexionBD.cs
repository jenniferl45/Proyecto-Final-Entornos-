﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Windows.Forms;
using System.Net;


namespace Proyecto_3_parcial
{
    class clsConexionBD
    {
        public SqlConnection SqlCon { get; private set; }

        public void Open()
        {
            /*
            string nombre_servidor = Dns.GetHostName();
            SqlCon = new SqlConnection($"Data Source={nombre_servidor}\\SQLEXPRESS;Initial Catalog=BD_Oscars;Integrated Security=True");
            SqlCon.Open();
            */
            string nombre_servidor = Dns.GetHostName();
            SqlCon = new SqlConnection($"Data Source=LAPTOP-QBKUD98I\\SQLEXPRESS;Initial Catalog=BD_Oscars;User ID=Alejandro;Password=Cachorro12;TrustServerCertificate=True");
            SqlCon.Open();
        }

        public void Close()
        {
            if (SqlCon != null && SqlCon.State == ConnectionState.Open)
            {
                SqlCon.Close();
            }
        }

        public string Cadena()
        {
            string nombre_servidor = Dns.GetHostName();
            return $"Data Source={nombre_servidor}\\SQLEXPRESS;Initial Catalog=BD_Oscars;Integrated Security=True";
        }

        public bool EjecutarComando(string query, SqlParameter[] parametros)
        {
            try
            {
                Open();
                using (SqlCommand comando = new SqlCommand(query, SqlCon))
                {
                    if (parametros != null)
                    {
                        comando.Parameters.AddRange(parametros);
                    }
                    comando.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
            finally
            {
                Close();
            }
        }

        public int Consulta_unico_valor(string query, SqlParameter[] parametros)
        {
            try
            {
                Open();
                SqlCommand comando = new SqlCommand(query, SqlCon);
                if (parametros != null)
                {
                    comando.Parameters.AddRange(parametros);
                }
                int result = (int)comando.ExecuteScalar();
                return result;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return 0;
            }
            finally
            {
                Close();
            }
        }
    }
}
