﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Proyecto_3_parcial
{
    public partial class frmNominaciones : Form
    {

        private clsUsuario usuarioLogueado;
        clsConexionBD conexionBD = new clsConexionBD();

        public frmNominaciones(clsUsuario usuarioLogueado)
        {
            InitializeComponent();
            this.usuarioLogueado = usuarioLogueado;
        }

        private void VerificarBotones()
        {
            if (!btnMejorPeli.Enabled && !btnMejorActor.Enabled && !btnMejorDirector.Enabled)
            {
                btnGuardarSalir.Enabled = true;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnMejorPeli_Click(object sender, EventArgs e)
        {
            frmMejor_Pelicula peli = new frmMejor_Pelicula(usuarioLogueado);
            peli.Show();
            btnMejorPeli.Enabled = false;
            VerificarBotones();
        }

        private void btnGuardarSalir_Click(object sender, EventArgs e)
        {




            string query = "UPDATE Usuarios SET Estado = 2 WHERE Nombre_Usuario = @Usuario";
            SqlParameter[] parametros = new SqlParameter[]
            {
            new SqlParameter("@Usuario", usuarioLogueado.getNombreUsuario())
            };

            try
            {
                conexionBD.Open();
                SqlCommand comando = new SqlCommand(query, conexionBD.SqlCon);
                comando.Parameters.AddRange(parametros);

                if (comando.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Votos guardados correctamente. Mantengase atento a los ganadores!");
                    this.Close();

                    Form1 inicio = new Form1();
                    inicio.Show();
                }
                else
                {
                    MessageBox.Show("Error al actualizar el estado del usuario.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conexionBD.Close();
            }
        }

        private void btnPelicula_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMejor_Pelicula pelicula = new frmMejor_Pelicula(usuarioLogueado);
            pelicula.Show();

            btnMejorPeli.Enabled = false;
            VerificarBotones();
        }

        private void btnMejorActor_Click(object sender, EventArgs e)
        {
            frmMejor_Actor acto = new frmMejor_Actor(usuarioLogueado);
            acto.Show();
            btnMejorActor.Enabled = false;
            VerificarBotones();
        }

        private void frmNominaciones_Load(object sender, EventArgs e)
        {

        }

        private void btnMejorDirector_Click(object sender, EventArgs e)
        {
            frmMejor_Director dire = new frmMejor_Director(usuarioLogueado);
            dire.Show();
            btnMejorPeli.Enabled = false;
            VerificarBotones();
        }
    }
}
