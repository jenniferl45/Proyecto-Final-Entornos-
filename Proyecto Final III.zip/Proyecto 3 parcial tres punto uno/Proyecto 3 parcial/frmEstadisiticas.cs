﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization;
using System.Windows.Forms.DataVisualization.Charting;

namespace Proyecto_3_parcial
{
    public partial class frmEstadisiticas : Form
    {
        private clsConexionBD conexionBD = new clsConexionBD();
        public frmEstadisiticas()
        {
            InitializeComponent();
            CargarDatos();
        }

        private void frmEstadisiticas_Load(object sender, EventArgs e)
        {

        }

        private void CargarDatos()
        {
            try
            {
                // Cargar datos para Película
                string queryPelicula = "SELECT * FROM Pelicula";
                DataTable dtPelicula = ObtenerDatos(queryPelicula);
                dgvPelicula.DataSource = dtPelicula;
                ActualizarChartPelicula(dtPelicula);

                // Cargar datos para Actor
                string queryActor = "SELECT * FROM Actor";
                DataTable dtActor = ObtenerDatos(queryActor);
                dgvActor.DataSource = dtActor;
                ActualizarChartActor(dtActor);

                // Cargar datos para Director
                string queryDirector = "SELECT * FROM Director";
                DataTable dtDirector = ObtenerDatos(queryDirector);
                dgvDirector.DataSource = dtDirector;
                ActualizarChartDirector(dtDirector);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message);
            }
        }

        private DataTable ObtenerDatos(string query)
        {
            DataTable dataTable = new DataTable();
            try
            {
                conexionBD.Open();
                SqlCommand comando = new SqlCommand(query, conexionBD.SqlCon);
                SqlDataAdapter dataAdapter = new SqlDataAdapter(comando);
                dataAdapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conexionBD.Close();
            }
            return dataTable;
        }

        private void ActualizarChartPelicula(DataTable dtPelicula)
        {
            chPelicula.Series.Clear();
            Series series = new Series("Películas");
            series.ChartType = SeriesChartType.Column;

            foreach (DataRow row in dtPelicula.Rows)
            {
                series.Points.AddXY(row["Nombre_Pelicula"], row["Recuento_Votos"]);
            }

            chPelicula.Series.Add(series);
        }

        private void ActualizarChartActor(DataTable dtActor)
        {
            chActor.Series.Clear();
            Series series = new Series("Actores");
            series.ChartType = SeriesChartType.Column;

            foreach (DataRow row in dtActor.Rows)
            {
                series.Points.AddXY(row["Nombre_Actor"], row["Recuento_Votos"]);
            }

            chActor.Series.Add(series);
        }

        private void ActualizarChartDirector(DataTable dtDirector)
        {
            chDirector.Series.Clear();
            Series series = new Series("Directores");
            series.ChartType = SeriesChartType.Column;

            foreach (DataRow row in dtDirector.Rows)
            {
                series.Points.AddXY(row["Nombre_Director"], row["Recuento_Votos"]);
            }

            chDirector.Series.Add(series);
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
