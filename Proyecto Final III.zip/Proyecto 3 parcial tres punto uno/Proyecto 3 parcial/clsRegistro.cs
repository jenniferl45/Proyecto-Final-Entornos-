﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Proyecto_3_parcial
{
    class clsRegistro
    {
        private string usuario;
        private string contraseña;
        private string correo;
        private string pregunta;
        private string respuesta;
        private string codigo;

        public clsRegistro()
        {
            usuario = string.Empty;
            contraseña = string.Empty;
            correo = string.Empty;
            pregunta = string.Empty;
            respuesta = string.Empty;
            codigo = string.Empty;
        }

        public clsRegistro(string usuario, string contraseña, string correo, string pregunta, string respuesta, string codigo)
        {
            this.usuario = usuario;
            this.contraseña = contraseña;
            this.correo = correo;
            this.pregunta = pregunta;
            this.respuesta = respuesta;
            this.codigo = codigo;
        }

        public string getUsuario() { return usuario; }
        public void setUsuario(string text) { usuario = text; }
        public string getContraseña() { return contraseña; }
        public void setContraseña(string text) { contraseña = text; }
        public string getCorreo() { return correo; }
        public void setCorreo(string text) { correo = text; }
        public string getPregunta() { return pregunta; }
        public void setPregunta(string text) { pregunta = text; }
        public string getRespuesta() { return respuesta; }
        public void setRespuesta(string value) { respuesta = value; }
        public string getCodigo() { return codigo; }
        public void setCodigo(string value) { codigo = value; }

    }
}
