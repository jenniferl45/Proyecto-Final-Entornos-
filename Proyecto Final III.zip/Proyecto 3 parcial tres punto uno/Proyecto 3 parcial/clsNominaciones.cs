﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_3_parcial
{
    // Homonimia: clsNominaciones representa una nominación genérica al Oscar
    class clsNominaciones  // Superclase
    {
        private int id;
        private string nombre;
        private string descripcion;
        private string foto;
        private string nombreFoto;
        private int idCategoria;

        // Constructor por defecto
        public clsNominaciones() { }

        // Constructor con parámetros
        public clsNominaciones(int id, string nombre, string descripcion, string foto, string nombreFoto, int idCategoria)
        {
            this.id = id;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.foto = foto;
            this.nombreFoto = nombreFoto;
            this.idCategoria = idCategoria;
        }

        // Propiedades públicas para acceder a los atributos privados
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }

        public string Foto
        {
            get { return foto; }
            set { foto = value; }
        }

        public string NombreFoto
        {
            get { return nombreFoto; }
            set { nombreFoto = value; }
        }

        public int IdCategoria
        {
            get { return idCategoria; }
            set { idCategoria = value; }
        }

        // Función virtual: permite que las subclases sobrescriban este método
        public virtual void mensaje()
        {
            Console.WriteLine("Mensaje genérico desde clsNominaciones");
        }
    }
}
