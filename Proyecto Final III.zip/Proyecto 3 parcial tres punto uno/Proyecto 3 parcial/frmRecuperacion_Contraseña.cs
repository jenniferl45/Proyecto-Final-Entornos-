﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Proyecto_3_parcial
{
    public partial class frmRecuperacion_Contraseña : Form
    {
        public frmRecuperacion_Contraseña()
        {
            InitializeComponent();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 inicio = new Form1();
            inicio.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;

            if (string.IsNullOrEmpty(usuario))
            {
                MessageBox.Show("Por favor ingresar los datos");
            }
            else
            {
                try
                {
                    clsConexionBD conexion = new clsConexionBD();
                    using (SqlConnection cn = conexion.SqlCon)
                    {
                        if (cn.State == ConnectionState.Open)
                        {
                            cn.Close();
                        }

                        cn.Open();


                        SqlCommand comandoPreguntaRecuperacion = new SqlCommand("SELECT Pregunta_Recuperacion FROM Usuarios WHERE Nombre_Usuario = @usuario", cn);
                        comandoPreguntaRecuperacion.CommandType = CommandType.Text;

                        comandoPreguntaRecuperacion.Parameters.AddWithValue("@usuario", usuario);

                        SqlDataReader reader = comandoPreguntaRecuperacion.ExecuteReader();

                        if (reader.Read())
                        {
                            string preguntaRecuperacion = reader["Pregunta_Recuperacion"].ToString();
                            lblPregunta.Text = preguntaRecuperacion;

                            MessageBox.Show("Usuario encontrado");
                            label1.Enabled = false;
                            txtUsuario.Enabled = false;
                            btnBuscar.Enabled = false;

                            lblPregunta.Show();
                            lblIngrese.Show();
                            txtRespuesta_Recuperacion.Show();
                            btnSiguiente.Show();
                        }
                        else
                        {
                            MessageBox.Show("Usuario no encontrado");
                        }

                        reader.Close();
                        cn.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {

        }
    }
    
}
